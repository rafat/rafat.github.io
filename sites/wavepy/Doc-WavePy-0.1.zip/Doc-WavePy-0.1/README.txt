"signals" folder contains images/signals used in example codes.
Python example scripts are available in HTML/Demos
IPython HTML demos are available at HTML/Ipython-Demo 

Homepage: http://wavepy.sourceforge.net/index.html